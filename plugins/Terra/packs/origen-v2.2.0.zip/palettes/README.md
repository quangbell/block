# Palettes

This directory contains all palette configs which are utilized by biomes to
determine what blocks make up the base terrain. These configs are placed into
loosely defined subdirectories based on what kind of biome and or area in the
world they may appear in.